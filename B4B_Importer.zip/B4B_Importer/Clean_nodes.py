import bpy

def delete_all_except_output_node(material):
    """Delete all nodes in a material except the Material Output node."""
    # Ensure the material has a node tree
    if not material.use_nodes:
        material.use_nodes = True

    # Access the node tree of the material
    node_tree = material.node_tree

    # Remove all nodes except the Material Output node
    for node in node_tree.nodes:
        if node.type != 'OUTPUT_MATERIAL':
            node_tree.nodes.remove(node)

def clear_nodes():
    """Clear nodes for all materials in the scene, preserving only Material Output nodes."""
    # Iterate through all materials in the scene
    for material in bpy.data.materials:
        if material.users > 0:  # Check if the material is used in the scene
            delete_all_except_output_node(material)

# Run the clear_nodes function to apply changes to all materials
clear_nodes()
