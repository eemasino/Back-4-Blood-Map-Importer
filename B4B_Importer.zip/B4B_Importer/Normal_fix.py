import bpy

# Helper function to trace connections and find image texture nodes
def find_connected_texture_node(input_socket):
    # If the input socket is not linked, return None
    if not input_socket.is_linked:
        return None

    # Trace back through the connected nodes
    linked_node = input_socket.links[0].from_node
    
    # If we find an image texture node, return it
    if linked_node.type == 'TEX_IMAGE':
        return linked_node
    
    # If the linked node is not an image texture, check its inputs recursively
    for input in linked_node.inputs:
        texture_node = find_connected_texture_node(input)
        if texture_node:
            return texture_node
    
    return None

# Iterate through all materials in the scene
for material in bpy.data.materials:
    if material.use_nodes:  # Check if the material uses nodes
        # Access the node tree of the material
        node_tree = material.node_tree
        
        # Iterate through all nodes in the material's node tree
        for node in node_tree.nodes:
            # Check if the node is a Principled BSDF shader
            if node.type == 'BSDF_PRINCIPLED':
                # Get the input socket for the Normal channel
                normal_input = node.inputs.get("Normal")
                
                # Trace back to find any connected texture node
                texture_node = find_connected_texture_node(normal_input)
                
                # If we found a texture node, change its color space
                if texture_node:
                    current_color_space = texture_node.image.colorspace_settings.name
                    print(f"Found texture: {texture_node.name} indirectly connected to Normal in material: {material.name} with color space: {current_color_space}")
                    
                    # Change color space to Non-Color if it's not already set
                    if current_color_space != 'Non-Color':
                        texture_node.image.colorspace_settings.name = 'Non-Color'
                        print(f"Changed color space to Non-Color for texture: {texture_node.name} in material: {material.name}")
                    else:
                        print(f"Texture {texture_node.name} in {material.name} is already set to Non-Color.")
                
print("Finished updating texture nodes connected (directly or indirectly) to Normal inputs.")
