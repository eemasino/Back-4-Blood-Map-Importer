bl_info = {
    "name": "Back 4 Blood Map Importer",
    "blender": (3, 6, 0),
    "category": "Import-Export",
    "version": (1, 0, 0),
    "author": "eemas",
    "description": "Addon to import maps, clean nodes, apply materials, and fix normal maps using custom scripts."
}

import bpy
import os
from bpy.props import StringProperty
from bpy.types import Operator, Panel
import importlib.util

# Get the path to the current addon directory
addon_directory = os.path.dirname(os.path.abspath(__file__))

# Create a new panel for the UI

def import_map(asset_path, map_dir):
    # Normalize and convert paths to absolute paths
    map_dir = os.path.abspath(os.path.normpath(map_dir))
    asset_path = os.path.abspath(os.path.normpath(asset_path))
    print(f"Normalized Map Directory: {map_dir}")
    print(f"Normalized Asset Directory: {asset_path}")
    print(f"Map Directory Type: {type(map_dir)}, Length: {len(map_dir)}")
    print(f"Asset Directory Type: {type(asset_path)}, Length: {len(asset_path)}")
    
    # Check if map_dir exists
    if not os.path.exists(map_dir):
        print(f"Map directory not found at: {map_dir}")
        return

    # Check if asset_path exists
    if not os.path.exists(asset_path):
        print(f"Asset directory not found at: {asset_path}")
        return

    # Load the map_importer.py script dynamically
    script_path = os.path.join(addon_directory, 'map_importer.py')
    spec = importlib.util.spec_from_file_location("map_importer", script_path)
    map_importer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(map_importer)

    # Define the missing function `split_object_path`
    if not hasattr(map_importer, 'split_object_path'):
        def split_object_path(object_path):
            # Assuming the object path format is like: "/Game/Folder/Subfolder/AssetName.AssetName"
            # This function extracts and returns the path without the asset name duplication

            # Remove the "/Game/" part if it exists
            if object_path.startswith("/Game/"):
                object_path = object_path.replace("/Game/", "", 1)

            # Remove anything after the first period (usually AssetName.AssetName format)
            object_path = object_path.split('.')[0]

            return object_path

        map_importer.split_object_path = split_object_path

    # Execute the script's logic by calling a function directly
    if hasattr(map_importer, 'run_import'):
        map_importer.run_import(map_dir, asset_path)
    else:
        print("run_import function not found in map_importer script.")

# Create a new panel for the UI

# Create a new panel for the UI
class ImportMapPanel(Panel):
    bl_label = "Map Importer"
    bl_idname = "SCENE_PT_map_importer"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Map Importer"

    def draw(self, context):
        layout = self.layout
        scn = context.scene

        layout.prop(scn, "asset_directory", text="Assets Path")
        layout.prop(scn, "map_directory", text="Map JSON Directory")
        layout.operator("import_map.button", text="Import Map")
        layout.operator("clean_nodes.button", text="Clean Nodes")
        layout.operator("apply_material.button", text="Apply Material")
        layout.operator("fix_normals.button", text="Fix Normal Maps")

# Operator to import the map

# Operator to import the map
class IMPORT_OT_map_button(Operator):
    bl_idname = "import_map.button"
    bl_label = "Import Map"

    def execute(self, context):
        # Extract paths from scene properties
        scn = context.scene
        asset_dir = scn.asset_directory
        map_dir = scn.map_directory

        # Debugging print statements to see the paths being passed
        print(f"Asset Directory: {asset_dir}")
        print(f"Map Directory: {map_dir}")

        # Validate paths
        
        
        # Run the map importer script with the given paths
        import_map(asset_dir, map_dir)
        return {'FINISHED'}

# Operator to apply materials
class APPLY_OT_material_button(Operator):
    bl_idname = "apply_material.button"
    bl_label = "Apply Material"

    def execute(self, context):
        # Extract asset directory from scene properties
        scn = context.scene
        asset_dir = scn.asset_directory

        # Load the material_importer.py script dynamically and pass asset_dir
        script_path = os.path.join(addon_directory, "Material_importer.py")
        if os.path.exists(script_path):
            spec = importlib.util.spec_from_file_location("material_importer", script_path)
            material_importer = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(material_importer)

            # Ensure the material importer script has a function to apply materials
            if hasattr(material_importer, 'apply_materials'):
                material_importer.apply_materials(asset_dir)
            else:
                self.report({'ERROR'}, "apply_materials function not found in material_importer script.")
        else:
            self.report({'ERROR'}, f"File not found: {script_path}")
        return {'FINISHED'}

# Operator to clean material nodes
class CLEAN_OT_nodes_button(Operator):
    bl_idname = "clean_nodes.button"
    bl_label = "Clean Nodes"

    def execute(self, context):
        # Run the clean nodes script
        script_path = os.path.join(addon_directory, "Clean_nodes.py")
        if os.path.exists(script_path):
            exec(open(script_path).read(), globals())
        else:
            self.report({'ERROR'}, f"File not found: {script_path}")
        return {'FINISHED'}

# Operator to fix normal maps
class FIX_OT_normals_button(Operator):
    bl_idname = "fix_normals.button"
    bl_label = "Fix Normal Maps"

    def execute(self, context):
        # Run the normal fix script
        script_path = os.path.join(addon_directory, "Normal_fix.py")
        if os.path.exists(script_path):
            exec(open(script_path).read(), globals())
        else:
            self.report({'ERROR'}, f"File not found: {script_path}")
        return {'FINISHED'}

# Register the panel and properties
classes = [
    ImportMapPanel,
    IMPORT_OT_map_button,
    APPLY_OT_material_button,
    CLEAN_OT_nodes_button,
    FIX_OT_normals_button,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.asset_directory = StringProperty(name="Asset Directory", subtype='DIR_PATH')
    bpy.types.Scene.map_directory = StringProperty(name="Map JSON Directory", subtype='DIR_PATH')

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.asset_directory
    del bpy.types.Scene.map_directory

if __name__ == "__main__":
    register()
