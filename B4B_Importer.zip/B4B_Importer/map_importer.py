import bpy
import json
import mathutils
from mathutils import Euler
import math
import os

# importer toggles
import_static = True
import_lights = False  # enable to also import lights

# Import types supported by the script
static_mesh_types = [
    'StaticMeshComponent',
    # 'InstancedStaticMeshComponent'  # buggy, positions wrong, seems to be used with splines as well
]
light_types = [
    'SpotLightComponent',
    'AnimatedLightComponent',
    'PointLightComponent'
]

def run_import(map_dir, base_dir):
    # Validate map_dir and base_dir
    if not os.path.exists(map_dir):
        print(f"Map directory not found: {map_dir}")
        return

    if not os.path.exists(base_dir):
        print(f"Asset base directory not found: {base_dir}")
        return

    map_files = [os.path.join(map_dir, f) for f in os.listdir(map_dir) if f.endswith('.json')]
    
    for map in map_files:
        print('Processing file', map)

        if not os.path.exists(map):
            print('File not found, skipping.', map)
            continue

        json_filename = os.path.basename(map)
        import_collection = bpy.data.collections.new(json_filename)
        
        bpy.context.scene.collection.children.link(import_collection)

        with open(map) as file: 
            json_object = json.load(file)
            print("-------------============================-------------")

            # Handle the different entity types
            for entity in json_object:
                if not entity.get('Type', None):
                    continue

                if import_lights and entity.get('Type') in light_types:
                    print(entity)
                    light = GameLight(entity)
                    light.import_light(import_collection)

                if import_static and entity.get('Type') in static_mesh_types:
                    static_mesh = StaticMesh(entity, base_dir)
                    static_mesh.import_staticmesh(import_collection)
                    continue

    print('Done.')

class StaticMesh:
    entity_name = ""
    import_path = ""
    pos = [0, 0, 0]
    rot = [0, 0, 0]
    scale = [1, 1, 1]
    
    no_entity = False
    no_file = False
    no_mesh = False
    no_path = False
    base_shape = False

    def __init__(self, json_entity, base_dir):
        self.entity_name = json_entity.get("Outer", 'Error')

        props = json_entity.get("Properties", None)
        if not props:
            print('Invalid Entity: Lacking property')
            self.no_entity = True
            return

        if not props.get("StaticMesh", None):
            print('Invalid Property: does not contain a static mesh')
            self.no_mesh = True
            return

        object_path = props.get("StaticMesh").get("ObjectPath", None)
        
        if not object_path or object_path == '':
            print('Invalid StaticMesh: does not contain ObjectPath.')
            self.no_path = True
            return

        if 'BasicShapes' in object_path:
            print('This is a BasicShape - skipping for now')
            self.base_shape = True
            return

        objpath = split_object_path(object_path)
        objpath = objpath.replace("/Game/", "", 1)  # Remove only the first occurrence
        self.import_path = os.path.join(base_dir, objpath + ".gltf")
        print('Mesh Path', self.import_path)
        self.no_file = not os.path.exists(self.import_path)

        if props.get("RelativeLocation", False):
            pos = props.get("RelativeLocation")
            self.pos = [pos.get("X")/100, pos.get("Y")/-100, pos.get("Z")/100]

        if props.get("RelativeRotation", False):
            rot = props.get("RelativeRotation")
            self.rot = [rot.get("Roll"), rot.get("Pitch")*-1, rot.get("Yaw")*-1]

        if props.get("RelativeScale3D", False):
            scale = props.get("RelativeScale3D")
            self.scale = [scale.get("X", 1), scale.get("Y", 1), scale.get("Z", 1)]

    @property
    def invalid(self):
        return self.no_path or self.no_file or self.no_entity or self.base_shape or self.no_mesh

    def import_staticmesh(self, collection):
        if self.invalid:
            print('Refusing to import due to failed checks.')
            return False

        bpy.ops.import_scene.gltf(filepath=self.import_path)
        imported_obj = bpy.context.object
        
        imported_obj.name = self.entity_name
        imported_obj.scale = (self.scale[0], self.scale[1], self.scale[2])
        imported_obj.location = (self.pos[0], self.pos[1], self.pos[2])
        imported_obj.rotation_mode = 'XYZ'
        imported_obj.rotation_euler = Euler((math.radians(self.rot[0]), math.radians(self.rot[1]), math.radians(self.rot[2])), 'XYZ')
        collection.objects.link(imported_obj)
        bpy.context.scene.collection.objects.unlink(imported_obj)

        print('StaticMesh imported:', self.entity_name)
        return imported_obj


class GameLight:
    entity_name = ""
    type = ""

    pos = [0, 0, 0]
    rot = [0, 0, 0]
    scale = [1, 1, 1]

    energy = 1000

    no_entity = False

    def __init__(self, json_entity):
        self.entity_name = json_entity.get("Outer", 'Error')
        self.type = json_entity.get("SpotLightComponent", "SpotLightComponent")

        props = json_entity.get("Properties", None)
        if not props:
            print('Invalid Entity: Lacking property')
            self.no_entity = True
            return

        if props.get("RelativeLocation", False):
            pos = props.get("RelativeLocation")
            self.pos = [pos.get("X")/100, pos.get("Y")/-100, pos.get("Z")/100]

        if props.get("RelativeRotation", False):
            rot = props.get("RelativeRotation")
            self.rot = [rot.get("Roll"), rot.get("Pitch")*-1, rot.get("Yaw")*-1]

        if props.get("RelativeScale3D", False):
            scale = props.get("RelativeScale3D")
            self.scale = [scale.get("X", 1), scale.get("Y", 1), scale.get("Z", 1)]

    def import_light(self, collection):
        if self.no_entity:
            print('Refusing to import due to failed checks.')
            return False

        if self.type == 'SpotLightComponent':
            light_data = bpy.data.lights.new(name=self.entity_name, type='SPOT')
        elif self.type == 'PointLightComponent':
            light_data = bpy.data.lights.new(name=self.entity_name, type='POINT')
        
        light_obj = bpy.data.objects.new(name=self.entity_name, object_data=light_data)
        light_obj.scale = (self.scale[0], self.scale[1], self.scale[2])
        light_obj.location = (self.pos[0], self.pos[1], self.pos[2])
        light_obj.rotation_mode = 'XYZ'
        light_obj.rotation_euler = Euler((math.radians(self.rot[0]), math.radians(self.rot[1]), math.radians(self.rot[2])), 'XYZ')
        collection.objects.link(light_obj)
